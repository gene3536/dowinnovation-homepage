dnl $Id$
dnl config.m4 for extension SciSecuX_PCC

dnl Comments in this file start with the string 'dnl'.
dnl Remove where necessary. This file will not work
dnl without editing.

dnl If your extension references something external, use with:

dnl PHP_ARG_WITH(SciSecuX_PCC, for SciSecuX_PCC support,
dnl Make sure that the comment is aligned:
dnl [  --with-SciSecuX_PCC             Include SciSecuX_PCC support])

dnl Otherwise use enable:

PHP_ARG_ENABLE(SciSecuX_PCC, whether to enable SciSecuX_PCC support,
Make sure that the comment is aligned:
[  --enable-SciSecuX_PCC           Enable SciSecuX_PCC support])

if test "$PHP_SCISECUX_PCC" != "no"; then
  dnl Write more examples of tests here...

  dnl # --with-SciSecuX_PCC -> check with-path
  dnl SEARCH_PATH="/usr/local /usr"     # you might want to change this
  dnl SEARCH_FOR="/include/SciSecuX_PCC.h"  # you most likely want to change this
  dnl if test -r $PHP_SCISECUX_PCC/$SEARCH_FOR; then # path given as parameter
  dnl   SCISECUX_PCC_DIR=$PHP_SCISECUX_PCC
  dnl else # search default path list
  dnl   AC_MSG_CHECKING([for SciSecuX_PCC files in default path])
  dnl   for i in $SEARCH_PATH ; do
  dnl     if test -r $i/$SEARCH_FOR; then
  dnl       SCISECUX_PCC_DIR=$i
  dnl       AC_MSG_RESULT(found in $i)
  dnl     fi
  dnl   done
  dnl fi
  dnl
  dnl if test -z "$SCISECUX_PCC_DIR"; then
  dnl   AC_MSG_RESULT([not found])
  dnl   AC_MSG_ERROR([Please reinstall the SciSecuX_PCC distribution])
  dnl fi

  dnl # --with-SciSecuX_PCC -> add include path
  dnl PHP_ADD_INCLUDE($SCISECUX_PCC_DIR/include)

  dnl # --with-SciSecuX_PCC -> check for lib and symbol presence
  dnl LIBNAME=SciSecuX_PCC # you may want to change this
  dnl LIBSYMBOL=SciSecuX_PCC # you most likely want to change this 

  dnl PHP_CHECK_LIBRARY($LIBNAME,$LIBSYMBOL,
  dnl [
  dnl   PHP_ADD_LIBRARY_WITH_PATH($LIBNAME, $SCISECUX_PCC_DIR/lib, SCISECUX_PCC_SHARED_LIBADD)
  dnl   AC_DEFINE(HAVE_SCISECUX_PCCLIB,1,[ ])
  dnl ],[
  dnl   AC_MSG_ERROR([wrong SciSecuX_PCC lib version or lib not found])
  dnl ],[
  dnl   -L$SCISECUX_PCC_DIR/lib -lm -ldl
  dnl ])
  dnl
  dnl PHP_SUBST(SCISECUX_PCC_SHARED_LIBADD)

  PHP_NEW_EXTENSION(SciSecuX_PCC, SciSecuX_PCC.c, $ext_shared)
fi
