<?
include_once $_SERVER["DOCUMENT_ROOT"]."/_config/config.php";

	$enc_retInfo  =  $_GET["retInfo"];      // 파라메터로 받은 정보

	//-[복호화] ----------------------------------------------------------------------------------
    	$dec_retInfo   = exec(DOC_DIR."/_prog/_realname/seoul/SCIVName_V1 2 $enc_retInfo ");     // 요청정보 복호화
	//-[복호화] ----------------------------------------------------------------------------------

	//파라미터 분리
	$totInfo = split("/", $dec_retInfo);

	$dec_reqNum		= $totInfo[0];	// 복호화된 요청번호
    $dec_vDiscrNo	= $totInfo[1];	// 복호화된 가상식별번호 
    $dec_name		= $totInfo[2];  // 복호화된 성명
    $dec_result		= $totInfo[3];  // 복호화된 실명확인결과값
	$dec_discrHash	= $totInfo[4];	// 복호화된 중복가입확인정보
	$dec_msg		= $totInfo[5];
	$msgChk			= "오류";

	//-[위조/변조 여부 검증] ----------------------------------------------------------------------------------
		$cmpMsg = exec(DOC_DIR."/_prog/_realname/seoul/SCIVName_HMac_V1 1 $dec_reqNum$dec_vDiscrNo$dec_result");

			if ($dec_msg == $cmpMsg)
			{
				$msgChk = "정상";
			}
	//-[위조/변조 여부 검증] ----------------------------------------------------------------------------------

	$dec_discrHash = exec(DOC_DIR."/_prog/_realname/seoul/HttpSecuX_IPIN 2 $dec_discrHash");

/**
echo "<pre>";
print_r($totInfo);
echo "</pre>";
**/
//복호화된 결과
if($dec_result!=1)
{
	echo "<script>
		alert('실명인증 후에 이용해 주세요".$dec_result."');
		location.href='/_prog/realname/realname_form.php';
		</script>
		";
	exit;

}

$dec_name = str_replace("/","",$dec_name);
$dec_vDiscrNo = str_replace("/","",$dec_vDiscrNo);

if($dec_name && $dec_vDiscrNo && $dec_result == 1) 
{
	
	$_SESSION["sess_user"]["nm"] 				= iconv("euc-kr","UTF-8",$dec_name);												//이름
	$_SESSION["sess_user"]["rrno"] 				= "";																				//주민번호
	$_SESSION["sess_user"]["dupe_mbsh_cfm_cd"] 	= $totInfo[4];																	//중복가입확인코드
	$_SESSION["sess_user"]["group"] 			= 100; 																				//그룹코드
	$_SESSION["sess_user"]["foreigner"] 		= "";																				//외국인여부
	$_SESSION["sess_user"]["sex_dvs_cd"] 		= $rets[3];																			//성별구분
	$_SESSION["sess_user"]["birth_dt"] 			= substr($rets[5],0,4)."-".substr($rets[5],4,2)."-".substr($rets[5],6,2);			//생년월일
	$_SESSION["sess_user"]["prsn_cfm_cd"] 		= $dec_vDiscrNo		//개인확인코드


	//개인식별코드 및 중복확인코드 UPDATE
	if($SESS_USERID) {
	
		include $_SERVER["DOCUMENT_ROOT"]."/conf/lib/db_conn.php"; 
		echo $sql = "update member set dupcode='', realcode='".$dec_vDiscrNo."' where userid='".$SESS_USERID."' and dupcode ='' and realcode=''";
		$db->update($sql);
	}




	$return_url = base64_decode($_GET["return_url"]);
	if(!$return_url) $return_url = $_SESSION['SESS_RETURN_URL'];
	if(!$return_url) $return_url = "/";
	
	echo "<script>
			//alert('실명인증이 정상적으로 처리 되었습니다.');
			document.location.href='".$return_url."';
			//window.close();
		</script>
			";
	exit;

}
/***
//암호화된 요청번호
//echo $enc_reqNum;

//암호화된 가상식별번호
//echo $enc_vDiscrNo;

//암호화된 성명
//echo $enc_name;

//암호화된 결과
echo $enc_result;


//복호화된 요청번호 
echo $dec_reqNum ;

//복호화된 가상식별번호
echo $dec_vDiscrNo;

//복호화된 성명
echo $dec_name;

//복호화된 결과
echo $dec_result;
****/

echo $_SESSION["sess_realname"][10];
exit;
?>