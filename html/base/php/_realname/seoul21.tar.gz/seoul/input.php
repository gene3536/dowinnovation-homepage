<?

	//고유식별번호생성
	list($hour, $min, $sec, $day, $month, $year) = explode(" ",date("H i s d m Y")); 
	$sci_num = mktime($hour, $min, $sec, $month, $day, $year); 
?>
<script type='text/javascript'>  
<!--
    var CBA_window; 

    function openCBAWindow()
    { 
        CBA_window = window.open('', 'CbaWindow', 'width=410, height=450, resizable=0, scrollbars=no, status=0, titlebar=0, toolbar=0, left=300, top=200' );

        if(CBA_window == null){ 
            var ua = window.navigator.userAgent;
            var msie = ua.indexOf ( "MSIE" );
            var msxp = ua.indexOf ( "Windows NT 5.1" );
            var msxpsp2 = ua.indexOf ( " SV1" );

            if(msie >0 && msxp >0 && msxpsp2 >0){
                alert("※ MSN,야후,구글 팝업 차단 툴바가 설치된 경우 팝업허용을 해주셔야만 가상식별검증이 가능합니다. \n\n※ 윈도우 XP SP2 사용자일 경우에는 화면 상단에 있는 팝업 차단 알림줄을 클릭하여 팝업을 \n    허용해 주시기 바랍니다.");
            }else{
                alert("※ MSN,야후,구글 팝업 차단 툴바가 설치된 경우 팝업허용을 해주셔야만 가상식별검증이 가능합니다."); 
            } 
        }

        document.reqCBAForm.action = 'https://name.siren24.com/vname/jsp/vname_j10.jsp';
        document.reqCBAForm.target = 'CbaWindow';
        document.reqCBAForm.submit();
    }
//-->
</script>
<form name="reqCBAForm" method="post" action="">  
    <input type="hidden" name="id"      value = "KGT010">                                                <!-- 실명확인 회원사 아이디 -->
    <input type="hidden" name="reqNum"  value = "<?=$sci_num?>">                                  <!-- 실명확인 요청번호      -->
    <input type="hidden" name="retUrl"  value = "http://<?=$_SERVER['HTTP_HOST']?>/_prog/_realname/seoul/output.php?return_url=<?=$return_url?>">            <!-- 실명확인 결과수신 URL  -->
</form>

<?

$_SESSION['SESS_RETURN_URL'] = "";
?>