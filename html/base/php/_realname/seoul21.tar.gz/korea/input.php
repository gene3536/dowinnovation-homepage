<?php 

	//**********************************************************************************************
	//한국신용평가정보 공공기관용 안심실명확인 서비스
	//req,사이트코드,사이트패스워드,return_url ,요청 seq ,Reserved 값을 암호화하여 
	//한국신용평가정보 안심실명확인 페이지호출시 암호화된 값을 넘겨준다.
	//작성일 : 2006.10.18
    //**********************************************************************************************	

 	//고객사 요청 Sequence 
	list($hour, $min, $sec, $day, $month, $year) = explode(" ",date("H i s d m Y")); 
	$pSeqid = mktime($hour, $min, $sec, $month, $day, $year); 

	$pSite_flag 	= "D043";   					// 사이트 id 
	$pSite_pwd  	= "53121585";   					// 사이트 비밀번호
	$pSeqid	   		= $pSeqid;					// 고객사 요청 Sequence 
	$pReturn_url	= "http://".$HTTP_HOST."/_prog/_realname/".REALNAME."/output.php";			// 결과값을 리턴 받으실 URL(업체에서 결과값을 받으실 URL입니다.)
	$pReserved1		= $return_url;					// 기타 Reserved data1
	$pReserved2		= "test2";						// 기타 Reserved data2
	$pReserved3		= "test3";						// 기타 Reserved data3
	$pReq			= "req";						// 값을 변경하시면 안됩니다.
		
	//echo $return_url;

	$cb_encode_path = DOC_DIR."/_prog/_realname/".REALNAME."/SafeNC";			// SafeNC 모듈이 설치된 위치 (웹디렉토리에 올리셔도 무방합니다.)
//	$cb_encode_path = "G:\\g_htdocs\\public_culture_firm\\_prog\\realname\\korea\\SafeNC.exe";			// SafeNC 모듈이 설치된 위치 (웹디렉토리에 올리셔도 무방합니다.) - 재국 테스트: \r 이런거  \\r 로 처리..
													// 데이타를 암호화,복호화 하는 모듈입니다.
	
	//**********************************************************************************************
	// SafeNC 파일을 실행하여 데이타를 암호화 합니다. 
	//**********************************************************************************************
	$enc_data = `$cb_encode_path $pReq $pSite_flag $pSite_pwd $pSeqid $pReturn_url $pReserved1 $pReserved2 $pReserved3`;		

	if ($enc_data == -1){
		$returnMsg = "암/복호화 시스템 오류";
		$enc_data = "";
	}else if ($enc_data == -2){
		$returnMsg = "암호화 처리 오류";
		$enc_data = "";
	}else if ($enc_data == -3){
		$returnMsg = "암호화 데이터 오류";
		$enc_data = "";
	}else if ($enc_data == -9){
		$returnMsg = "입력값 오류";
		$enc_data = "";
	}
	
?>

	<script type="text/javascript">
	   function openCBAWindow(){
	   		//한국신용평가정보 안심 실명확인 팝업페이지를 띄웁니다.	   
			window.open('', 'popup','width=410, height=590');
			document.form.target = "popup";
			document.form.action = "https://cert.namecheck.co.kr/certnc_input.asp";
			document.form.submit();
	   }
	</script> 

<form method="post" name="form" action="">
 	<input type="text" name="enc_data" value="<?=$enc_data?>" />
</form>
